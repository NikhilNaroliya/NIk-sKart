export { useData, DataProvider } from "./data/dataContext";

export { useAuth, AuthProvider } from "./auth/authContext";

document.title = 'ArtCart ';