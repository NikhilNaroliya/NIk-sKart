export { Home } from "./Home/Home";
export { Product } from "./Product/Product";
export { Cart } from "./Cart/Cart";
export { Wishlist } from "./Wishlist/Wishlist";
export { ProductPage } from "./Product/ProductPage";
export { UserProfile } from "./UserProfile/UserProfile";
export { Checkout } from "./Checkout/Checkout";
export { Error } from "./Error/Error";
// export {Home} from './Home/Home'
